//No puede lograr que en la configuración de la fecha en español la primera letra de la semana y del mes estuvieran en mayúscula,
//por lo que tuve que implementar esta función a la que se llama sobre el resultado en cost formato2 para alterarlo (línea 28).
function mayusculas_para_dia_y_mes_esES(formato) {
    
    //Esta función toma una cadena de texto y el carácter en la posición 0 y lo pone en mayúscula, luego lo concatena con la cadena sin el carácter en la possición 0.
    function primera_letra_mayuscula(cadena) {
        return cadena.charAt(0).toUpperCase() + cadena.slice(1);
    }

    //Dividimos el contenido de formato en palabras cada vez que encontremos un espacio en blanco.
    const palabras = formato.split(' ');

    /*Como ya sabemos que formato de palabras va a entrar en formato, podemos preveer con facilidad
    que la primera palabra que comenzará por tanto en la posición 0 será el día de la semana y la pasamos por la función function primera_letra_mayuscula.
    La tercera palabra será el mes, asi que también la pasamos por la función function primera_letra_mayuscula.
    */ 
    palabras[0] = primera_letra_mayuscula(palabras[0]);
    palabras[3] = primera_letra_mayuscula(palabras[3]);

    //Unimos de nuevo cada palabra individual del array const palabras en una única cadena de caracteres.
    return palabras.join(' ');
}

function anadir_sufijo_dia_ingles(formato1) {
/*Buscamos en const formato1 con match y mediante la expresion regular (/\d+/) números consecutivos.
Comenzará a buscar esos números consecutivos desde la posición 0 del array [0] que sabemos que contendrá el día.
Convertiremos esos números en caractéres a Int con parseInt para poder clasificarlos mas abajo en th, st, nd y rd.
*/
    const numeroDia = parseInt(formato1.match(/\d+/)[0]);

/*En inglés, los sufijos siguen las siguientes reglas:
    st: Para los números terminados en 1, pero no el 11.
    nd: Para los números terminados en 2, pero no el 12.
    rd: Para los números terminados en 3, pero no el 13.
    st: Para los números que no encajans en las tres reglas anteriores.

    sufijo tendrá la cadena th por defecto, y sólo si se cumplen las 3 primeras reglas cambiará.
*/
    let sufijo = 'th';
    if (numeroDia % 10 === 1 && numeroDia % 100 !== 11) {
        sufijo = 'st';
    } else if (numeroDia % 10 === 2 && numeroDia % 100 !== 12) {
        sufijo = 'nd';
    } else if (numeroDia % 10 === 3 && numeroDia % 100 !== 13) {
        sufijo = 'rd';
    }

/*
Volvemos a convertir numeroDia.toString de Int a cadena, para poder usar con él replace, que busca en formato3 una cadena exacta igual para reemplazarla.
La cadena en formato3 será reemplazada por una concatenación de numeroDia + sufijo.
Nota: replace tiene dos partes, primero es la cadena que se quiere reemplazar, el segundo por lo que se quiere reemplazar.
*/
    return formato3.replace(numeroDia.toString(), numeroDia + sufijo);
}

//Obtenemos la fecha actual del sistema.
const fechaActual = new Date();

//Configuramos el formato de fecha1 para su salida al HTML. El resultado sería algo como esto: 17/10/2023 y es almacenado en: const formato1
const formato1 = `${fechaActual.getDate()}/${fechaActual.getMonth() + 1}/${fechaActual.getFullYear()}`;

//Configuramos el formato de fecha2 para su salida al HTML. El resultado sería algo como esto: martes, 17 de octubre de 2023
//En opcionesFormato2 elegimos que configuración queremos tener para los diferentes apartados de la fecha:
//weekday: long, lo que significa que pondrá el nombre del día completo. También usado en month.
//day: numeric, lo representará mediante un número. También usado en year.
const opcionesFormato2 = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
//Almacenamos en formato2 la fecha actual del sistema formateada por toLocaleDateString con los parámetros regionales de español-España (es-ES) y las características de formato que especificamos en const opcionesFormato2.
const formato2 = fechaActual.toLocaleDateString('es-ES', opcionesFormato2);
//Procesamos formato2 para poner las primeras letras en mayúscula usando la función function mayusculas_para_dia_y_mes_esES(formato).
const formato2Modificado = mayusculas_para_dia_y_mes_esES(formato2);

//Configuramos el formato de fecha3 para su salida al HTML. El resultado sería algo como esto: Tuesday, October 17th, 2023
const opcionesFormato3 = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
const formato3 = fechaActual.toLocaleDateString('en-US', opcionesFormato3);
//Procesamos formato3 para poner el sufijo en inglés correspondiente al día en número.
const formato1Modificado = anadir_sufijo_dia_ingles(formato1);

//Enviamos al HTML todas las fechas en los formatos ya procesados anteriormente  a sus correspondiente IDs.
document.getElementById('fecha1').textContent = formato1;
document.getElementById('fecha2').textContent = formato2Modificado;
document.getElementById('fecha3').textContent = formato1Modificado;
//Derimán Tejera Fumero 2DAW Semi B