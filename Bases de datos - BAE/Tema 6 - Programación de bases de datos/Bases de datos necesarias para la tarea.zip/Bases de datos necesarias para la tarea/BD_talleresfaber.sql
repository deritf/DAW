
-- 1) CAMBIAR IP Y PUERTO en las líneas siguientes

-- conexión al esquema FREE
-- si es XE, reeplazar "FREE" por "XE" 
-- con el usuario sys y roll sysdba
connect sys/debianOracle@localhost:1521/FREE as sysdba;

alter pluggable database talleresfaber close;
-- alter pluggable database talleresfaber unplug into '/tmp/talleresfaber.pdb';
DROP pluggable database talleresfaber including datafiles;

-- creamos una base de datos pluggable
create pluggable database talleresfaber ADMIN USER talleresfaberadmin IDENTIFIED by talleresfaberadmin
  FILE_NAME_CONVERT=(
    '/opt/oracle/oradata/FREE/pdbseed/system01.dbf', '/opt/oracle/oradata/FREE/talleresfaber/system01.dbf',
    '/opt/oracle/oradata/FREE/pdbseed/sysaux01.dbf', '/opt/oracle/oradata/FREE/talleresfaber/sysaux01.dbf',
    '/opt/oracle/oradata/FREE/pdbseed/undotbs01.dbf', '/opt/oracle/oradata/FREE/talleresfaber/undotbs01.dbf',
    '/opt/oracle/oradata/FREE/pdbseed/temp01.dbf', '/opt/oracle/oradata/FREE/talleresfaber/temp01.dbf'
  )
  STORAGE UNLIMITED TEMPFILE REUSE;

-- abrimos la base de datos
alter pluggable database talleresfaber open;

-- cerrar base de datos
-- alter pluggable database talleresfaber close;

-- eliminar base de datos
-- drop pluggable database  talleresfaber;

show pdbs;

-- usamos la base de datos pluggable recién creada
alter session set container=talleresfaber;

-- o nos conectamos a la plugable con usuario de sistema
connect sys/debianOracle@localhost:1521/talleresfaber as sysdba;

-- especificamos las cuotas del usuario talleresfaberadmin
ALTER USER talleresfaberadmin QUOTA UNLIMITED ON "SYSTEM";
ALTER USER talleresfaberadmin QUOTA UNLIMITED ON "SYSAUX";

-- privilegios de usuario
grant ALL privileges to talleresfaberadmin;

-- roles de usuario
GRANT "CONNECT" TO talleresfaberadmin ;

-- conexión a la plugable con el nuevo usuario
connect talleresfaberadmin/talleresfaberadmin@localhost:1521/talleresfaber;


CREATE TABLE CLIENTES (
CodCliente VARCHAR(5) NOT NULL,
DNI VARCHAR(10) NOT NULL,
Apellidos VARCHAR(50),
Nombre VARCHAR(25),
Direccion VARCHAR(50),
Telefono VARCHAR(9),
PRIMARY KEY (CodCliente)
);

CREATE TABLE FACTURAS (
IdFactura NUMBER(4) NOT NULL,
FechaFactura DATE NOT NULL,
CodCliente VARCHAR(5) NOT NULL,
IdReparacion INTEGER,
PRIMARY KEY (IdFactura)
);

CREATE TABLE VEHICULOS (
Matricula VARCHAR(8) NOT NULL,
Marca VARCHAR(25),
Modelo VARCHAR(50),
Color VARCHAR(25),
FechaMatriculacion DATE,
CodCliente  VARCHAR(5),
PRIMARY KEY(Matricula)
);

CREATE TABLE REPARACIONES (
IdReparacion INTEGER NOT NULL,
Matricula VARCHAR(8) NOT NULL,
FechaEntrada DATE,
Km DECIMAL(8,2),
Avería VARCHAR(200),
FechaSalida DATE,
Reparado  NUMBER(1),
Observaciones VARCHAR(250),
PRIMARY KEY(IdReparacion)
);

CREATE TABLE Intervienen (
CodEmpleado VARCHAR(5),
IdReparacion INTEGER NOT NULL,
Horas DECIMAL(4,2),
PRIMARY KEY(CodEmpleado, IdReparacion)
);

CREATE TABLE EMPLEADOS (
CodEmpleado VARCHAR(5) NOT NULL,
DNI VARCHAR(10) NOT NULL,
Nombre VARCHAR(25),
Apellidos VARCHAR(50),
Dirección VARCHAR(50),
Telefono VARCHAR(9),
CP VARCHAR(5),
FechaAlta DATE,
Categoria VARCHAR(50),
PRIMARY KEY(CodEmpleado)
);

CREATE TABLE Incluyen (
IdRecambio VARCHAR(10) NOT NULL,
IdReparacion INTEGER NOT NULL,
Unidades SMALLINT,
PRIMARY KEY (IdRecambio, IdReparacion)
);

CREATE TABLE RECAMBIOS (
IdRecambio VARCHAR(10) NOT NULL,
Descripcion VARCHAR(100),
UnidadBase VARCHAR(50),
Stock SMALLINT, 
PrecioReferencia DECIMAL(6,2),
PRIMARY KEY(IdRecambio)
);

CREATE TABLE Realizan (
IdReparacion INTEGER NOT NULL,
Referencia VARCHAR(10) NOT NULL,
Horas DECIMAL(4,2),
PRIMARY KEY(IdReparacion, Referencia)
);

CREATE TABLE ACTUACIONES (
Referencia VARCHAR(10) NOT NULL,
Descripcion VARCHAR(100),
TiempoEstimado DECIMAL(4,2),
Importe DECIMAL(6,2),
PRIMARY KEY(Referencia)
);



INSERT INTO CLIENTES VALUES 
('00001','12345678A','Alvarez Martín','Isabel','Alameda de Osuna, N112, 2B, Madrid','111223344');
INSERT INTO CLIENTES VALUES 
('00002','23456789B','Ceballos López','Carlos','Avenida de los Castros, N27, Bajo, Santander','222334455');
INSERT INTO CLIENTES VALUES 
('00003','34567890C','Ruiz Esteban','Alfonso','Parque del Olivo, N7, 3, Reinosa','333445566');
INSERT INTO CLIENTES VALUES 
('00004','45678901D','Escudero Ruiz','Carmen','Paseo Pereda, N342, 2dcha, Santander','444556677');
INSERT INTO CLIENTES VALUES 
('00005','56789012E','Muriedas, Arce','Enrique','Calle Ruiz de Alda, N43, 1A, Torrelavega','555667788');
INSERT INTO CLIENTES VALUES 
('00006','67890123F','Arce Villegas','Manuel Antonio','Paseo Fernández Vallejo, N160, Bajo, Torrelavega','666778899');
INSERT INTO CLIENTES VALUES 
('00007','78901234G','Martínez Salces','María Luisa','Calle Valdenoja, N23, 4C, Santander','777889900');
INSERT INTO CLIENTES VALUES 
('00008','89012345H','Barquín Rodríguez','Antonio','Calle Fontaneda, s/n, Bajo, Reinosa','888990011');
INSERT INTO CLIENTES VALUES 
('00009','90123456I','Cos Herrero','Jesús','Calle Mayor, N10, Bajo, Correpoco','999001122');
INSERT INTO CLIENTES VALUES 
('00010','01234567J','Sanchez Valverde','Fernando','Travesía Peñafiel, N423, 1Izda, Valladolid','000112233');


INSERT INTO EMPLEADOS VALUES 
('10000','87654321A','Marta','Márquez Barcelona','Avenida del Sardinero, n1, 3C, Santander','112233444','39012',to_date('2009-03-21', 'yyyy-mm-dd'),'Encargada de recambios');
INSERT INTO EMPLEADOS VALUES 
('20000','76543210B','Joaquín','Ruiz Díaz','Calle Revilla, N2, 2Dcha, Astillero','223344555','39403',to_date('2008-06-01', 'yyyy-mm-dd'),'Oficial de 2ª, ayudante de mecánica');
INSERT INTO EMPLEADOS VALUES 
('30000','65432109C','Ernesto','Fernández Pellón','Avenida de Barreda, N327, bajo, Torrelavega','334455666','39300',to_date('2010-02-23', 'yyyy-mm-dd'),'Recepcionista');
INSERT INTO EMPLEADOS VALUES 
('40000','54321098D','Javier','Vegar Cos','Paseo Menéndez Pelayo, N42, 2dcha, Santander','445566777','39008',to_date('2008-01-12', 'yyyy-mm-dd'),'Jefe chapa/pintura');
INSERT INTO EMPLEADOS VALUES 
('50000','43210987E','Ana Luisa','González Fernández','Avenida del Alisal, N16, 1Izda, Santander','556677888','39011',to_date('2010-01-01', 'yyyy-mm-dd'),'Administrativo');
INSERT INTO EMPLEADOS VALUES 
('60000','32109876F','Tomás','Ruiz Cerezo','Paseo Fernándo Arce, N160, Bajo, Torrelavega','667788999','39315',to_date('2008-06-01', 'yyyy-mm-dd'),'Oficial de 2ª, ayudante de chapa/pintura');
INSERT INTO EMPLEADOS VALUES 
('70000','21098765G','José Carlos','Sáinz Mata','Calle Valdenoja, N12, 2F, Santander','777889900','39016',to_date('2009-10-16', 'yyyy-mm-dd'),'Oficial de 1ª, mecánico');
INSERT INTO EMPLEADOS VALUES 
('80000','10987654H','silvia','Robles Pereda','Calle Avelino García, N23, 4C, Heras','889900111','39213',to_date('2010-03-15', 'yyyy-mm-dd'),'Gerente de Administración');
INSERT INTO EMPLEADOS VALUES 
('90000','09876543I','Luis Jesús','Hermida Martínez','Calle del desfiladero, N101, Bajo, LLanes','990011222','33500',to_date('2008-01-12', 'yyyy-mm-dd'),'Jefe de electricidad');
INSERT INTO EMPLEADOS VALUES 
('11000','98765432J','Héctor','Díaz Trigo','Plaza de las Autonomías, N67, 5Izda, Santander','001122333','39316',to_date('2008-01-12', 'yyyy-mm-dd'),'Jefe de mecánica');

INSERT INTO VEHICULOS VALUES
('1122 ABC','Citroen','C3','Azul cobalto',to_date('2006-08-16', 'yyyy-mm-dd'),'00009');
INSERT INTO VEHICULOS VALUES
('2233 ABC','Ford','Mondeo','Gris metalizado',to_date('2008-06-21', 'yyyy-mm-dd'),'00002');
INSERT INTO VEHICULOS VALUES
('3344 ABC','Nissan','Primera','Negro metalizado',to_date('2006-03-22', 'yyyy-mm-dd'),'00009');
INSERT INTO VEHICULOS VALUES
('4455 ABC','Seat','León','Rojo',to_date('2001-01-19', 'yyyy-mm-dd'),'00005');
INSERT INTO VEHICULOS VALUES
('5566 ABC','Daewo','','Azul Cobalto',to_date('2006-08-16', 'yyyy-mm-dd'),'00008');
INSERT INTO VEHICULOS VALUES
('6677 ABC','Renault','Megane Privilege','Azul',to_date('2009-10-12', 'yyyy-mm-dd'),'00004');
INSERT INTO VEHICULOS VALUES
('7788 ABC','Opel','Corsa Personality','Negro',to_date('2010-11-26', 'yyyy-mm-dd'),'00003');
INSERT INTO VEHICULOS VALUES
('8899 ABC','BMW','X3','Verde',to_date('2009-01-05', 'yyyy-mm-dd'),'00002');
INSERT INTO VEHICULOS VALUES
('9900 ABC','Renault','Laguna','Blanco',to_date('2010-11-06', 'yyyy-mm-dd'),'00001');
INSERT INTO VEHICULOS VALUES
('0011 ABC','Hyundai','Tucson','Negro azabache',to_date('2010-09-22', 'yyyy-mm-dd'),'00007');
INSERT INTO VEHICULOS VALUES
('1111 DEF','Suzuki','Vitara','Gris magenta',to_date('2010-05-30', 'yyyy-mm-dd'),'00006');
INSERT INTO VEHICULOS VALUES
('1212 DEF','Citroen','C4','Azul Turquesa',to_date('2009-07-07', 'yyyy-mm-dd'),'00010');
INSERT INTO VEHICULOS VALUES
('1313 DEF','Seat','Ibiza','Gris',to_date('2009-12-23', 'yyyy-mm-dd'),'00003');
INSERT INTO VEHICULOS VALUES
('1414 DEF','Volkswagen','Golf','Azul marino',to_date('2010-08-15', 'yyyy-mm-dd'),'00004');
INSERT INTO VEHICULOS VALUES
('1515 DEF','Renault','Clio','Gris perla',to_date('2004-04-23', 'yyyy-mm-dd'),'00010');
INSERT INTO VEHICULOS VALUES
('1616 DEF','Seat','Leon','Rojo',to_date('2007-06-21', 'yyyy-mm-dd'),'00009');

INSERT INTO RECAMBIOS VALUES
('BD_000_111','Bomba de dirección','Unidad',12,3.25);
INSERT INTO RECAMBIOS VALUES
('TF_000_222','Tambor de freno','Unidad',6,120.00);
INSERT INTO RECAMBIOS VALUES
('AA_000_333','Amortiguación','Caja de 2 unidades',5,65.00);
INSERT INTO RECAMBIOS VALUES
('DF_000_444','Disco de freno','Caja 4 unidades',12,145.50);
INSERT INTO RECAMBIOS VALUES
('FA_000_555','Filtro de aceite','Unidad',12,89.00);
INSERT INTO RECAMBIOS VALUES
('CD_000_666','Correa de distribución','Unidad',12,105.00);
INSERT INTO RECAMBIOS VALUES
('BB_000_777','Bateria','Unidad',23,120.00);
INSERT INTO RECAMBIOS VALUES
('CD_000_888','Cremallera de dirección','Unidad',4,92.10);
INSERT INTO RECAMBIOS VALUES
('CC_000_999','Caja de cambios','Unidad',12,320.00);
INSERT INTO RECAMBIOS VALUES
('RR_111_111','Radiador','unidad',6,88.9);
INSERT INTO RECAMBIOS VALUES
('FA_111_222','Filtro de aire','Unidad',25,76.00);
INSERT INTO RECAMBIOS VALUES
('EE_111_333','Escobillas','Caja de 2 unidades',43,76.34);
INSERT INTO RECAMBIOS VALUES
('EM_111_444','Embrague','Juego de 2 unidades',2,112.00);
INSERT INTO RECAMBIOS VALUES
('TT_111_555','Trasmisión','Unidad',4,201.00);
INSERT INTO RECAMBIOS VALUES
('BJ_111_666','Bujías','Caja de 2 unidades',4,89.00);
INSERT INTO RECAMBIOS VALUES
('PF_111_777','Pastillas de freno','Caja de 2 unidades',6,145.00);
INSERT INTO RECAMBIOS VALUES
('TE_111_888','Tubo de escape','Unidad',7,210.00);
INSERT INTO RECAMBIOS VALUES
('CA_111_999','Compresor de aire acondicionado','Unidad',2,450.00);
INSERT INTO RECAMBIOS VALUES
('ZF_222_111','Zapatas de freno','Caja de 2 unidades',12,23.25);
INSERT INTO RECAMBIOS VALUES
('CA_222_222','Carburador','Unidad',5,350.00);
INSERT INTO RECAMBIOS VALUES
('JU_222_333','Juntas','Unidad',34,2.00);
INSERT INTO RECAMBIOS VALUES
('IN_222_444','Inyectores','2 Unidades', 12, 57.50);
INSERT INTO RECAMBIOS VALUES
('PL_222_555','Plaquetas','Juego de 4',6,60.94);
INSERT INTO RECAMBIOS VALUES
('RV_222_666','Mando regulación velocidad','Unidad',3,55.32);
INSERT INTO RECAMBIOS VALUES
('LD_222_777','Juego de lámparas delantero','2 Unidades',12,11.37);


INSERT INTO REPARACIONES VALUES
(1,'5566 ABC',to_date('2010-12-30', 'yyyy-mm-dd'),50000,'Posible desgaste de la correa de distribución',to_date('2011-01-01', 'yyyy-mm-dd'),1,'Sin observaciones');
INSERT INTO REPARACIONES VALUES
(2,'1313 DEF',to_date('2011-01-01', 'yyyy-mm-dd'),60000,'Ruido tubo de escape',to_date('2011-01-02', 'yyyy-mm-dd'),1,'Cambiar si es necesario');
INSERT INTO REPARACIONES VALUES
(3,'0011 ABC',to_date('2011-01-01', 'yyyy-mm-dd'),32000,'Revisar fogueo de inyectores',to_date('2011-01-03', 'yyyy-mm-dd'),1,'Ruido al arrancar en frío');
INSERT INTO REPARACIONES VALUES
(4,'1414 DEF',to_date('2011-01-03', 'yyyy-mm-dd'),2500,'Ruptura pieza mando regulación velocidad',to_date('2011-01-04', 'yyyy-mm-dd'),1,'Sin observaciones');
INSERT INTO REPARACIONES VALUES
(5,'9900 ABC',to_date('2011-01-03', 'yyyy-mm-dd'),83400,'No funciona aire acondicionado',to_date('2011-01-06', 'yyyy-mm-dd'),1,'Sin observaciones');
INSERT INTO REPARACIONES VALUES
(6,'1313 DEF',to_date('2011-01-03', 'yyyy-mm-dd'),61000,'Fundida lámpara faro delantero izquierdo',to_date('2011-01-04', 'yyyy-mm-dd'),1,'Sustutuir');
INSERT INTO REPARACIONES VALUES
(7,'4455 ABC',to_date('2011-01-04', 'yyyy-mm-dd'),10000,'Batería se descarga',to_date('2011-01-04', 'yyyy-mm-dd'),1,'Observar funcionamiento');
INSERT INTO REPARACIONES VALUES
(8,'4455 ABC',to_date('2011-01-05', 'yyyy-mm-dd'),10000,'No arranca. Posible sustitución bateria',to_date('2011-01-07', 'yyyy-mm-dd'),1,'Sin observaciones');
INSERT INTO REPARACIONES VALUES
(9,'1515 DEF',to_date('2011-01-07', 'yyyy-mm-dd'),45000,'Ruido amortiguadores',to_date('2011-01-08', 'yyyy-mm-dd'),0,'No acepta presupuesto');
INSERT INTO REPARACIONES VALUES
(10,'1212 DEF',to_date('2011-01-10', 'yyyy-mm-dd'),62300,'El radiador pierde agua',NULL,0,'Pendiente de entrega');


INSERT INTO ACTUACIONES VALUES
('1110001111','Cambiar correa de distribución',2.5,125.00);
INSERT INTO ACTUACIONES VALUES
('1110002222','Cambiar tubo de escape',3,150.00);
INSERT INTO ACTUACIONES VALUES
('1110003333','Sustituir junta de inyectores',2.70,135.00);
INSERT INTO ACTUACIONES VALUES
('1110004444','Sustitución mando regulación velocidad',0.60,30.00);
INSERT INTO ACTUACIONES VALUES
('1110005555','Cambiar compresor de aire acondicionado',3.30,160.50);
INSERT INTO ACTUACIONES VALUES
('1110006666','Cambiar batería',1.3,60.50);
INSERT INTO ACTUACIONES VALUES
('1110007777','Sustitución escobillas',0.70,35.00);
INSERT INTO ACTUACIONES VALUES
('1110008888','Sustitución de lámparas',0.20,10.00);
INSERT INTO ACTUACIONES VALUES
('1110009999','Limpieza de inyectores',1.75,87.50);
INSERT INTO ACTUACIONES VALUES
('1111110000','Sustitución correa transmisión', 2.15, 100.75);
INSERT INTO ACTUACIONES VALUES
('1112220000','Limpieza carburador',2.10,100.50);
INSERT INTO ACTUACIONES VALUES
('1113330000','Cambio filtro aceite',0.70,35.00);
INSERT INTO ACTUACIONES VALUES
('1114440000','Cambiar junta',0.20,10.00);
INSERT INTO ACTUACIONES VALUES
('1115550000','Sustituir líquido de frenos',0.5,25.00);
INSERT INTO ACTUACIONES VALUES
('1116660000','Cambiar amortiguadores',1.5,75.00);
INSERT INTO ACTUACIONES VALUES
('1117770000','Cambiar radiador',2.50,120.50);
INSERT INTO ACTUACIONES VALUES
('1118880000','Limpiar Bujías',0.30,20.50);

INSERT INTO FACTURAS VALUES
(0010,to_date('2011-01-01', 'yyyy-mm-dd'),'00005','1');
INSERT INTO FACTURAS VALUES
(0011,to_date('2011-01-03', 'yyyy-mm-dd'),'00007','2');
INSERT INTO FACTURAS VALUES
(0012,to_date('2011-01-03', 'yyyy-mm-dd'),'00001','3');
INSERT INTO FACTURAS VALUES
(0013,to_date('2011-01-05', 'yyyy-mm-dd'),'00005','6');
INSERT INTO FACTURAS VALUES
(0014,to_date('2011-01-07', 'yyyy-mm-dd'),'00006','5');
INSERT INTO FACTURAS VALUES
(0015,to_date('2011-01-07', 'yyyy-mm-dd'),'00010','4');
INSERT INTO FACTURAS VALUES
(0016,to_date('2011-01-07', 'yyyy-mm-dd'),'00006','7');
INSERT INTO FACTURAS VALUES
(0017,to_date('2011-01-10', 'yyyy-mm-dd'),'00005','8');
INSERT INTO FACTURAS VALUES
(0018,to_date('2011-01-10', 'yyyy-mm-dd'),'00002','10');

INSERT INTO Realizan VALUES
(1,'1110001111',2.50);
INSERT INTO Realizan VALUES
(1,'1114440000',0.20);
INSERT INTO Realizan VALUES
(2,'1110002222',3.00);
INSERT INTO Realizan VALUES
(3,'1110009999',1.75);
INSERT INTO Realizan VALUES
(3,'1110003333',3.00);
INSERT INTO Realizan VALUES
(4,'1110004444',0.60);
INSERT INTO Realizan VALUES
(5,'1110005555',3.30);
INSERT INTO Realizan VALUES
(6,'1110008888',0.30);
INSERT INTO Realizan VALUES
(6,'1110007777',0.10);
INSERT INTO Realizan VALUES
(7,'1110006666',1.30);
INSERT INTO Realizan VALUES
(8,'1110006666',1.30);
INSERT INTO Realizan VALUES
(8,'1114440000',0.20);
INSERT INTO Realizan VALUES
(10,'1117770000',2.5);
INSERT INTO Realizan VALUES
(10,'1114440000',0.20);
INSERT INTO Realizan VALUES
(10,'1118880000',0.30);

INSERT INTO Incluyen VALUES
('CD_000_666',1,1);
INSERT INTO Incluyen VALUES
('JU_222_333',1,2);
INSERT INTO Incluyen VALUES
('TE_111_888',2,1);
INSERT INTO Incluyen VALUES
('IN_222_444',3,2);
INSERT INTO Incluyen VALUES
('PL_222_555',3,1);
INSERT INTO Incluyen VALUES
('RV_222_666',4,1);
INSERT INTO Incluyen VALUES
('CA_111_999',5,1);
INSERT INTO Incluyen VALUES
('LD_222_777',6,1);
INSERT INTO Incluyen VALUES
('EE_111_333',6,1);
INSERT INTO Incluyen VALUES
('BB_000_777',7,1);
INSERT INTO Incluyen VALUES
('BB_000_777',8,1);
INSERT INTO Incluyen VALUES
('JU_222_333',8,1);
INSERT INTO Incluyen VALUES
('RR_111_111',10,1);
INSERT INTO Incluyen VALUES
('JU_222_333',10,2);


INSERT INTO Intervienen VALUES
('20000',1,2.00);
INSERT INTO Intervienen VALUES
('70000',1,0.50);
INSERT INTO Intervienen VALUES
('20000',2,3.10);
INSERT INTO Intervienen VALUES
('40000',2,3.10);
INSERT INTO Intervienen VALUES
('70000',3,1.50);
INSERT INTO Intervienen VALUES
('11000',3,1.20);
INSERT INTO Intervienen VALUES
('90000',4,0.20);
INSERT INTO Intervienen VALUES
('60000',4,0.40);
INSERT INTO Intervienen VALUES
('20000',5,1.00);
INSERT INTO Intervienen VALUES
('60000',5,0.75);
INSERT INTO Intervienen VALUES
('40000',6,0.30);
INSERT INTO Intervienen VALUES
('11000',7,0.30);
INSERT INTO Intervienen VALUES
('20000',7,0.30);
INSERT INTO Intervienen VALUES
('90000',8,1.00);
INSERT INTO Intervienen VALUES
('20000',8,0.75);
INSERT INTO Intervienen VALUES
('70000',9,0.10);
INSERT INTO Intervienen VALUES
('70000',10,0.50);
INSERT INTO Intervienen VALUES
('20000',10,0.10);



ALTER TABLE FACTURAS
ADD CONSTRAINT FACT_FK_CodCli FOREIGN KEY(CodCliente )REFERENCES CLIENTES(CodCliente);
ALTER TABLE FACTURAS
ADD CONSTRAINT FACT_FK_IdRep FOREIGN KEY(IdReparacion )REFERENCES REPARACIONES(IdReparacion);

ALTER TABLE VEHICULOS
ADD CONSTRAINT VEHIC_FK_CodCli FOREIGN KEY(CodCliente )REFERENCES CLIENTES(CodCliente);

ALTER TABLE REPARACIONES
ADD CONSTRAINT REPAR_FK_CodRep FOREIGN KEY(Matricula )REFERENCES VEHICULOS(Matricula);


ALTER TABLE Intervienen
ADD CONSTRAINT Inter_FK_CodEm FOREIGN KEY(CodEmpleado) REFERENCES EMPLEADOS(CodEmpleado);
ALTER TABLE Intervienen
ADD CONSTRAINT Inter_FK_IdRep FOREIGN KEY(IdReparacion) REFERENCES REPARACIONES(IdReparacion);

ALTER TABLE Incluyen
ADD CONSTRAINT Incluy_FK_IdRec FOREIGN KEY(IdRecambio) REFERENCES RECAMBIOS(IdRecambio);
ALTER TABLE Incluyen
ADD CONSTRAINT Incluy_FK_IdRep FOREIGN KEY(IdReparacion) REFERENCES REPARACIONES(IdReparacion);

ALTER TABLE Realizan
ADD CONSTRAINT Real_FK_Refer FOREIGN KEY(Referencia) REFERENCES ACTUACIONES(Referencia);
ALTER TABLE Realizan
ADD CONSTRAINT Real_FK_IdRep FOREIGN KEY(IdReparacion) REFERENCES REPARACIONES(IdReparacion);


